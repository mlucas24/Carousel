module.exports = {
  dbUser: 'Jimmy',
  dbPass: 'Cats',
  dbHost: 'localhost',
  dbPort: '27017',
  dbName: 'IkeaCars',
  serverPort: '3015',
  dbLong: 'mongodb+srv://Jimmy:L7Ed1a4dpuhUEal4@cluster0-qtoyy.mongodb.net/test?retryWrites=true&w=majority',
};
